﻿using System.Diagnostics;
using System.Windows;

namespace SongList
{
    public class Song
    {
        public string FilePathToPlay { get; set; }

        public string Title
        {
            get;
            set;
        }

        public int ReleaseYear
        {
            get;
            set;
        }

        public Song() { }

        public Song(string myTitle, int myReleaseYear)
        {
            this.Title = myTitle;
            this.ReleaseYear = myReleaseYear;
        }

        public Song(string myTitle, int myReleaseYear, string FilePathToPlay) : this(myTitle, myReleaseYear)
        {
            this.FilePathToPlay = FilePathToPlay;
        }

        public void Play()
        {
            Process.Start(FilePathToPlay);
        }

    }
}
